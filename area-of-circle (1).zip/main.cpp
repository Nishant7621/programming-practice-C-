#include <iostream>
using namespace std;
int main()
{
    float r=2.3;
    float a=3.14*r*r;
    cout<<"Area is:";
    cout<<a<<endl;
    return 0;
    
}
